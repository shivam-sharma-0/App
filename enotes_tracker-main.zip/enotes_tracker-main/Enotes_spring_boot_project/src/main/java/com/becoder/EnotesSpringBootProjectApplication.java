package com.becoder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnotesSpringBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnotesSpringBootProjectApplication.class, args);
	}

}
