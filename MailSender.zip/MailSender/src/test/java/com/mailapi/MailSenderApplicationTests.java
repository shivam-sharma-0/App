package com.mailapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailSenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
