package com.exceltomysql.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelToDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
