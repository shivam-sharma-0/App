package com.exceltomysql.demo.Controller;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ExcelExportController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/export/excel")
    public ResponseEntity<InputStreamResource> exportToExcel() throws IOException, SQLException {
        String sql = "SELECT * FROM excel_data"; // Adjust the query according to your table

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Data");

            if (!rows.isEmpty()) {
                Row headerRow = sheet.createRow(0);
                Map<String, Object> headerMap = rows.get(0);
                int headerCellIndex = 0;
                for (String key : headerMap.keySet()) {
                    Cell cell = headerRow.createCell(headerCellIndex++);
                    cell.setCellValue(key);
                }

                int rowIndex = 1;
                for (Map<String, Object> rowData : rows) {
                    Row row = sheet.createRow(rowIndex++);
                    int cellIndex = 0;
                    for (Object value : rowData.values()) {
                        Cell cell = row.createCell(cellIndex++);
                        cell.setCellValue(value != null ? value.toString() : "");
                    }
                }
            }

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());

            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=data.xlsx");

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new InputStreamResource(in));
        }
    }
}
