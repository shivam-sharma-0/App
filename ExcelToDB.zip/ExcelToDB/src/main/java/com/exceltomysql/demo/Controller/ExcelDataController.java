package com.exceltomysql.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.exceltomysql.demo.Entity.ExcelData;
import com.exceltomysql.demo.Service.ExcelDataService;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ExcelDataController {

    @Autowired
    private ExcelDataService excelDataService;
    
    @PostMapping("/upload")
    public ResponseEntity<?> handleFileUpload(@RequestParam("file") MultipartFile file) {
        try {
            List<ExcelData> dataList = excelDataService.readExcel(file.getInputStream());
            excelDataService.saveDataToDatabase(dataList);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to read the Excel file", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("An error occurred while processing the file", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @PostMapping("/upload")
//    public String handleFileUpload(@RequestParam("file") MultipartFile file) {
//        try {
//            List<ExcelData> dataList = excelDataService.readExcel(file.getInputStream());
//            excelDataService.saveDataToDatabase(dataList);
//            return "Data successfully saved to the database.";
//        } catch (IOException e) {
//            e.printStackTrace();
//            return "Failed to save data.";
//        }
//    }

    @GetMapping("/data")
    public List<ExcelData> getAllData() {
        return excelDataService.getAllData();
    }
}

