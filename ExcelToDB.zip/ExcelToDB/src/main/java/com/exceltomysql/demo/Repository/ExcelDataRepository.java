package com.exceltomysql.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exceltomysql.demo.Entity.ExcelData;

public interface ExcelDataRepository extends JpaRepository<ExcelData, Long> {
}
